import requests
import time

# 请求 URL
url = "https://juhe.gateway.yofijoy.com/juhe/api/user/getLoginToken"

# 生成当前时间戳（毫秒级）
current_timestamp = int(time.time() * 1000)

# 请求参数
payload = {
    "extension": '{"centerflag":"mlbb_gb8090","sdkid":"200","channelid":"80010","account_id":"12306754","server_id":"58","time":"1735824727","is_adult":"1","sign":"ed0ba1a01d9d289f6f92eacbc24a9e4a","juheChannel":"52"}',
    "appId": "1000040",
    "channelId": "52",
    "timestamp": str(current_timestamp),  # 替换为当前时间戳
    "sign": "9c4cc84abbf0697428b554bc38a1a928"
}

# 请求头
headers = {
    "Accept": "application/json",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Accept-Language": "zh-CN,zh-TW;q=0.9,zh;q=0.8,en;q=0.7",
    "Cache-Control": "no-cache",
    "Connection": "keep-alive",
    "Content-Length": "408",
    "Content-Type": "application/x-www-form-urlencoded",
    "Host": "juhe.gateway.yofijoy.com",
    "Origin": "https://mlgbcdn.bigrnet.com",
    "Pragma": "no-cache",
    "Referer": "https://mlgbcdn.bigrnet.com/",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "cross-site",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36",
    "baseData": '{"os":5,"sub_channel":null}',
    "sec-ch-ua": '"Not A(Brand";v="8", "Chromium";v="132", "Google Chrome";v="132"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"'
}

# 发送 POST 请求
response = requests.post(url, data=payload, headers=headers)

# 输出响应结果
print("Status Code:", response.status_code)
print("Response Body:", response.text)