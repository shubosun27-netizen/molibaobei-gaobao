
// 新增本地存储操作方法 ==============
// 生成SHA1哈希作为key
async function generateStorageKey() {
    const input = document.getElementById('gameurl-input').value;
    const encoder = new TextEncoder();
    const data = encoder.encode(input);
    const hashBuffer = await crypto.subtle.digest('SHA-1', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// 存储配置
async function setStorageItem(att, value) {
    // const key = await generateStorageKey();
    // let config = await getStorageItem();
    // config[att] = value;
    // localStorage.setItem(key, JSON.stringify(config));
}

// 读取配置
async function getStorageItem() {
    // const key = await generateStorageKey();
    // const value = JSON.parse(localStorage.getItem(key))
    // console.warn(localStorage.getItem(key), value);
    // return value;
}

// 账号登录
function handleAccountLoginButtonClick() {
    contentFrame.contentWindow.iframeCallBack();
}

// 快速战斗
function handleQuickBattleCheckboxClick() {
    const checkbox = document.getElementById('quick-battle-checkbox');
    if (checkbox.checked) {
        window.QuickBattle = true;
        console.log("快速战斗已启用");
        // 在这里添加启用快速战斗的逻辑
        contentFrame.contentWindow.startRptBattleEndTimer();
        setStorageItem('QuickBattle', true);
    } else {
        window.QuickBattle = false;
        console.log("快速战斗已禁用");
        // 在这里添加禁用快速战斗的逻辑
        contentFrame.contentWindow.stopRptBattleEndTimer();
        setStorageItem('QuickBattle', false);
    }
}

// 增加背包物品信息
function addItemToBag(bagInfo, itemInfo) {
    bagItemList.innerHTML = '';
    // 检查 itemInfo 是否存在
    if (itemInfo) {
        bagInfo.forEach(({ index, count }) => {
            // 从 itemInfo 中获取物品名称
            const name = itemInfo[index]?.info_cn_1;
            if (name) {
                const option = document.createElement('option');
                option.value = index;
                // 使用模板字符串构建文本内容
                option.textContent = `${name}(${count}个)`;
                bagItemList.appendChild(option);
            }
        });
    }
}


// 清空挂机地图列表
function clearMapList() {
    mapList.innerHTML = '';
}

// 增加地图列表
function addMapToList(mapId, mapName) {
    const option = document.createElement('option');
    option.value = mapId;
    option.textContent = mapName;
    mapList.appendChild(option);
}

// 偷菜排行榜列表
function addHunterToList(rank) {
    // 清空列表
    hunterList.innerHTML = '';
    // 遍历排行榜数据
    for (let i = 0; i < rank.length; i++) {
        const option = document.createElement('option');
        option.value = i;
        option.textContent = rank[i].name;
        hunterList.appendChild(option);
    }
}

// 清空副本地图列表
function clearDungeonMapList() {
    dungeonMapList.innerHTML = '';
}
// 增加副本地图列表
function addDungeonMapToList(mapId, mapName) {
    const option = document.createElement('option');
    option.value = mapId;
    option.textContent = mapName;
    dungeonMapList.appendChild(option);
}

// 快速遇敌
function handleBattleMonsterButtonClick() {
    // console.log("点击了BattleMonstere按钮", battleMonsterButton.textContent);

    if (battleMonsterButton.textContent === "快速遇敌已启用") {
        window.QuicktBattleMonster = false;
        contentFrame.contentWindow.stopBattleMonsterTimer();
        battleMonsterButton.textContent = "快速遇敌已禁用";
        setStorageItem('QuicktBattleMonster', false);
        return;
    }
    window.QuicktBattleMonster = true;
    contentFrame.contentWindow.startBattleMonsterTimer();
    battleMonsterButton.textContent = "快速遇敌已启用";
    setStorageItem('QuicktBattleMonster', true);
}

// 进入游戏事件
function handleEnterGameButtonClick() {
    // 获取游戏地址输入框的值
    const gameUrlInput = document.getElementById('gameurl-input');
    const gameUrl = new URL(gameUrlInput.value);

    // 获取URLSearchParams对象
    const params = gameUrl.searchParams;

    // 将游戏地址加载到iframe中
    contentFrame.src = `http://116.62.210.96/1.0.213_JuheH5.html?${params.toString()}`;
}

// 进入地图事件
function handleEnterMapButtonClick() {
    const selectedMapId = mapList.value;
    console.log('当前选择的地图ID:', selectedMapId);
    contentFrame.contentWindow.enterDungeonEvent(selectedMapId);
    // 在这里执行进入地图的逻辑
    // 例如，跳转到对应的地图页面
    // window.location.href = `map.html?id=${selectedMapId}`;
}

// 宝石
function handleBuyBaoshiCheckboxClick() {
    const checkbox = document.getElementById('buy-baoshi-checkbox');
    setStorageItem('buyBaoshi', checkbox.checked);
    checkbox.checked ? contentFrame.contentWindow.scheduleFunction() : contentFrame.contentWindow.cancelBuyBaoshiTimer();
    setStorageItem('buyBaoshi', checkbox.checked);
}

// 自动打卡
function handleAutoDakaCheckboxClick() {
    const checkbox = document.getElementById('auto-daka-checkbox');
    checkbox.checked ? window.autoDaka = true : window.autoDaka = false;
    // 触发每日任务
    // contentFrame.contentWindow.scheduleEveryTask();
}

// 沙漏
function handleAutoShalouCheckboxClick() {
    const checkbox = document.getElementById('auto-shalou-checkbox');
    checkbox.checked ? window.autoShalou = true : window.autoShalou = false;
}

// 禁地
function handleJindiCheckboxClick() {
    const checkbox = document.getElementById('auto-jindi-checkbox');    // 获取禁地开关
    checkbox.checked ? window.autoJindi = true : window.autoJindi = false;  // 设置禁地开关
    const count = document.getElementById('auto-jindi-count');  // 获取禁地次数
    contentFrame.contentWindow.autoJindiCount = parseInt(count.value);  // 设置禁地次数
}

// 禁地，手动模式
function jindiManualmodeClick() {
    contentFrame.contentWindow.jindi = true;    // 设置禁地手动模式
    const count = document.getElementById('auto-jindi-count');  // 获取禁地次数
    contentFrame.contentWindow.autoJindiCount = parseInt(count.value);  // 设置禁地次数
    contentFrame.contentWindow.jindiEvent();    // 执行禁地事件
}

// 钓鱼
function handleAutoFishCheckboxClick() {
    const checkbox = document.getElementById('auto-fishing-checkbox');
    checkbox.checked ? window.autoFish = true : window.autoFish = false;
}

// 狩猎
function handleAutoHunterCheckboxClick() {
    const checkbox = document.getElementById('auto-hunting-checkbox');
    checkbox.checked ? contentFrame.contentWindow.autoMonsterHunter = true : contentFrame.contentWindow.autoMonsterHunter = false;
}

// 狩猎，手动模式
function huntingManualmodeClick() {
    contentFrame.contentWindow.monsterHunter();
}

// 星宫
function handleAutoStarPalaceCheckboxClick() {
    const checkbox = document.getElementById('auto-star-palace-checkbox');
    checkbox.checked ? contentFrame.contentWindow.autoStarPalace = true : contentFrame.contentWindow.autoStarPalace = false;
}

// 星空，手动模式
function starPalaceManualmodeClick() {
    contentFrame.contentWindow.starPalace();
}

// 百人
function handleManualmodeDao100Click() {
    dao100ManualMode.checked ? contentFrame.contentWindow.autoDao100 = true : contentFrame.contentWindow.autoDao100 = false;
}

// 自动刷副本
function handleAutoDungeonCheckboxClick() {
    const checkbox = document.getElementById('auto-dungeon-checkbox');
    checkbox.checked ? window.autoDungeon = true : window.autoDungeon = false;
}

// 手动刷副本
function handleManualmodeDungeonClick() {
    if (contentFrame.contentWindow.fuben_zhandou) {
        contentFrame.contentWindow.fuben_zhandou = false;
        dungeonManualmode.textContent = "手动模式";
        dungeonManualmode.style.color = "";
    } else {
        handleAutoDungeonClick();
        dungeonManualmode.textContent = "停止手动";
        dungeonManualmode.style.color = "red";
    }
}

// 刷副本函数
function handleAutoDungeonClick() {
    // 查询次数
    if (contentFrame.contentWindow.fuben && contentFrame.contentWindow.fuben.attackDungeonTimes == 0) {
        console.warn('副本次数已用完');
        return;
    }

    // 先停止挂机，再移动到副本地图，再购买材料，再打BOSS
    // 判断次数用完，自动返回挂机地点

    // 第一步,停止挂机
    if (window.QuicktBattleMonster) {
        handleBattleMonsterButtonClick();
    }

    // 获取剩余次数
    contentFrame.contentWindow.kinkoo_qk.reqTeamMaseInfo(0);

    // 第二步,移动到副本地图
    const selectedMapId = dungeonMapList.value;
    console.log('当前选择的地图ID:', selectedMapId);
    contentFrame.contentWindow.fuben_mapId = selectedMapId;
    contentFrame.contentWindow.autoDungeon_receiveMessage();
}

// 偷菜
function handlehunterButtonClick() {
    const selectedHunterId = hunterList.value;
    console.log('当前选择的偷菜ID:', selectedHunterId, contentFrame.contentWindow.rankInfo[parseInt(selectedHunterId)]);
    let userId = contentFrame.contentWindow.rankInfo[parseInt(selectedHunterId)].userId;
    contentFrame.contentWindow.kinkoo_shoulie.monsterHunterEventReq(12);
    contentFrame.contentWindow.kinkoo_shoulie.reqEnterGate(userId);
}

// 自动购买物品
function handleAutoBuyCheckboxClick() {
    contentFrame.contentWindow.autoBuyItem();
}

// 卖垃圾
function handleSellItemButtonClick() {
    contentFrame.contentWindow.sellItem();
}

// 套圈
function handleTaoQuanButtonClick() {
    const pos = document.getElementById('tao-quan-pos');  // 套圈的位置
    contentFrame.contentWindow.kinkoo_huodong.reqActivityQWTQReward(parseInt(pos.value));
}

// 勇士小游戏得分
function handleMiniGameButtonClick(score, time) {
    const guan = document.getElementById('mini-game-value').value;
    contentFrame.contentWindow.kinkoo_game.reqReward(parseInt(guan), score, time);

}

// 数独游戏得分
function handleSudokuGameButtonClick(level, score, time) {
    contentFrame.contentWindow.kinkoo_shudu.reqReward(parseInt(level), parseInt(score), time);
}

// 奇妙魔石小游戏得分
function handleStoneGameButtonClick(level, score, time) {
    contentFrame.contentWindow.kinkoo_qimiaomoshi.reqReward(parseInt(level), parseInt(score), time);
}

// 食品店小游戏得分
function handleFoodGameButtonClick(level, score) {
    contentFrame.contentWindow.kinkoo_napanshipindian.reqReward(parseInt(level), parseInt(score));
}

// 消消乐小游戏得分
function handleXXLGameButtonClick(level, score, time) {
    contentFrame.contentWindow.kinkoo_xiaoxiaole.reqReward(parseInt(level), parseInt(score), time);
}

// 果蔬消消乐小游戏得分
function handleGSXXLGameButtonClick(level, score, time) {
    contentFrame.contentWindow.kinkoo_gsxxl.reqReward(parseInt(level), parseInt(score), time);
}

// 自动领红包
function handleAutoRedBagCheckboxClick() {
    const checkbox = document.getElementById('auto-redbag-checkbox');
    checkbox.checked ? contentFrame.contentWindow.autoRedBag = true : contentFrame.contentWindow.autoRedBag = false;
}

function handleMonitorShopItemsCheckboxClick() {
    const checkbox = document.getElementById('monitor-shop-items-checkbox');
    checkbox.checked ? contentFrame.contentWindow.autoMonitorShopItems = true : contentFrame.contentWindow.autoMonitorShopItems = false;
    contentFrame.contentWindow.autoMonitorShopItems ? contentFrame.contentWindow.scheduleMonitorShopItems() : contentFrame.contentWindow.cancelMonitorShopItems();
}

function monitorShopItemsManualmodeClick() {
    contentFrame.contentWindow.monitorShopItems();
}

// 群里之墓
function handleAutoGodAreCheckboxClick() {
    const checkbox = document.getElementById('auto-god-are-checkbox');
    checkbox.checked ? contentFrame.contentWindow.autoGadAre = true : contentFrame.contentWindow.autoGadAre = false;
    checkbox.checked ? contentFrame.contentWindow.autoGadAreEvent() : null;

}

// 领取宠物召唤券
function handleAutoCWZHJCheckboxClick() {
    const checkbox = document.getElementById('auto-CWZHJ-checkbox');
    checkbox.checked ? contentFrame.contentWindow.autoCWZHJ = true : contentFrame.contentWindow.autoCWZHJ = false;
    checkbox.checked ? contentFrame.contentWindow.autoCWZHJEvent() : null;
}

// 领取心愿召唤券
function handleAutoYWZHJCheckboxClick() {
    const checkbox = document.getElementById('auto-YWZHJ-checkbox');
    checkbox.checked ? contentFrame.contentWindow.autoYWZHJ = true : contentFrame.contentWindow.autoYWZHJ = false;
    checkbox.checked ? contentFrame.contentWindow.autoYWZHJEvent() : null;
}